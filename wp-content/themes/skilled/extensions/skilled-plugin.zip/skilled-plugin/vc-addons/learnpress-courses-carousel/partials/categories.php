<?php if ( ( (int) $show_category ) && $category_output != '' ) : ?>
	<p class="sensei-course-meta">
		<span><i class="icon-Address-Book2"></i></span>
		<span class="course-category"><?php echo $category_output; ?></span>
	</p>
<?php endif; ?>
